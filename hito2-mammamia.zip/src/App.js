import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import RegisterPage from './components/RegisterPage';
import LoginPage from './components/LoginPage';
import './App.css';

function App() {
  const [showLogin, setShowLogin] = useState(true);

  return (
    <div className="app">
      <Navbar />
      <main className="main-area">
        <div className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h2>{showLogin ? 'Iniciar Sesión' : 'Registro'}</h2>
            <button className="toggle-btn" onClick={() => setShowLogin(!showLogin)}>
              {showLogin ? 'Ir a Registro' : 'Ir a Login'}
            </button>
          </div>

          {showLogin ? <LoginPage /> : <RegisterPage />}
        </div>
      </main>
      <Footer />
    </div>
  );
}

export default App;