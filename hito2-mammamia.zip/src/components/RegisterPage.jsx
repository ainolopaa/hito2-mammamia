import React, { useState } from 'react';

const RegisterPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [message, setMessage] = useState(null);
  const [type, setType] = useState(''); 

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email || !password || !confirmPassword) {
      setType('error'); setMessage('Todos los campos son obligatorios.');
      return;
    }
    if (password.length < 6) {
      setType('error'); setMessage('La contraseña debe tener al menos 6 caracteres.');
      return;
    }
    if (password !== confirmPassword) {
      setType('error'); setMessage('Las contraseñas no coinciden.');
      return;
    }
    setType('success');
    setMessage('Registro exitoso. ¡Bienvenida/o a Pizzería Mamma Mía!');
    
    setEmail(''); setPassword(''); setConfirmPassword('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>Email:</label>
      <input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="ejemplo@correo.com" />

      <label>Contraseña:</label>
      <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Mínimo 6 caracteres" />

      <label>Confirmar Contraseña:</label>
      <input type="password" value={confirmPassword} onChange={e=>setConfirmPassword(e.target.value)} placeholder="Repite la contraseña" />

      <div style={{ display:'flex', justifyContent:'flex-end', marginTop:10 }}>
        <button type="submit">Registrar</button>
      </div>

      {message && <div className={`message ${type==='success' ? 'success' : 'error'}`}>{message}</div>}
    </form>
  );
};

export default RegisterPage;