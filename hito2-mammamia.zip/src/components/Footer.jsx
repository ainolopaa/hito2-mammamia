import React from 'react';

const Footer = () => {
  return (
    <footer style={{ padding: '16px 24px', background: 'rgba(0,0,0,0.45)', color: 'white', textAlign: 'center' }}>
      © {new Date().getFullYear()} Pizzería Mamma Mía — Hecho con ❤️
    </footer>
  );
};

export default Footer;