import React, { useState } from 'react';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState(null);
  const [type, setType] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email || !password) {
      setType('error'); setMessage('Todos los campos son obligatorios.');
      return;
    }
    if (password.length < 6) {
      setType('error'); setMessage('La contraseña debe tener al menos 6 caracteres.');
      return;
    }
    
    if (email === 'admin@pizza.com' && password === '123456') {
      setType('success'); setMessage('Login exitoso. ¡Bienvenido a Pizzería Mamma Mía!');
      setEmail(''); setPassword('');
    } else {
      setType('error'); setMessage('Credenciales incorrectas.');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>Email:</label>
      <input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="ejemplo@correo.com" />

      <label>Contraseña:</label>
      <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Mínimo 6 caracteres" />

      <div style={{ display:'flex', justifyContent:'flex-end', marginTop:10 }}>
        <button type="submit">Ingresar</button>
      </div>

      {message && <div className={`message ${type==='success' ? 'success' : 'error'}`}>{message}</div>}
    </form>
  );
};

export default LoginPage;