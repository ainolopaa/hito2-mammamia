import React from 'react';

const Navbar = () => {
  return (
    <header style={{ padding: '12px 24px', background: 'rgba(0,0,0,0.35)', color: 'white', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <div style={{ fontWeight: '700' }}>🍕 Pizzería Mamma Mía</div>
      <nav>
        <a href="#" style={{ color: 'white', marginRight:12, textDecoration:'none' }}>Inicio</a>
        <a href="#" style={{ color: 'white', marginRight:12, textDecoration:'none' }}>Menú</a>
        <a href="#" style={{ color: 'white', textDecoration:'none' }}>Contacto</a>
      </nav>
    </header>
  );
};

export default Navbar;