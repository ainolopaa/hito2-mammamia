import React from "react";
import "./App.css";
import headerImg from "./assets/pizza-restaurant-email-header.jpg";

function App() {
  return (
    <div
      className="app-container"
      style={{
        backgroundImage: `url(${headerImg})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        minHeight: "100vh",
      }}
    >
      <header
        style={{
          backgroundColor: "rgba(37, 136, 175, 0.89)",
          color: "white",
          padding: "20px",
          textAlign: "center",
        }}
      >
        <h1>Pizzería Mamma Mía 🍕</h1>
        <p>¡Las mejores pizzas al estilo italiano!</p>
      </header>
    </div>
  );
}

export default App;
