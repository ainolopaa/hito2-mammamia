Pizzería Mamma Mía - Hito 2

Instrucciones:
1. Descomprime el ZIP.
2. Ejecuta: npm install
3. Ejecuta: npm start

El proyecto fue creado para ser usado con Create React App. Incluye:
- Navbar y Footer con estilo similar al Hito 1
- Formulario de Login y Registro con validaciones
- Botón para alternar entre Login y Registro
- Fondo (header.jpg) en src/assets/